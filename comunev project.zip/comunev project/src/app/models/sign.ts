export class User{
    FirstName: string;
    LastName: string;
    Username: string;
    Password: string;
    DOB: Date;
    Country: string
    
}